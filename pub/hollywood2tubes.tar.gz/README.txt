---
README

Hollywood2Tubes
Pascal Mettes
Spot On: Action Localization from Pointly-Supervised Proposals
ECCV
2016
---

---
CITATION

When using the dataset, please cite our work:

@article{mettes2016spot,
  title={Spot On: Action Localization from Pointly-Supervised Proposals},
  author={Mettes, Pascal and van Gemert, Jan C and Snoek, Cees G M},
  journal={ECCV},
  year={2016}
}
---

---
CONTENTS

point-annotations/ - The folder containing the annotations on the training set.
box-annotations/   - The folder containing the annotations on the test set.

---

---
FILE FORMAT

- In both base folders, there is a separate folder for each individual video.
- The folder of a single video contains the annotations, a hdf5 file for each
  action present in the video.
- The name of the action is the first word in the filename of the hdf5 file.

File example (explanation below):

-
>> h5dump box-annotations/actioncliptest00005/StandUp-annotations.hdf5 

HDF5 "box-annotations/actioncliptest00005/StandUp-annotations.hdf5" {
GROUP "/" {
   DATASET "0" {
      DATATYPE  H5T_IEEE_F32LE
      DATASPACE  SIMPLE { ( 13, 5 ) / ( 13, 5 ) }
      DATA {
      (0,0): 0, -1, -1, -1, -1,
      (1,0): 10, -1, -1, -1, -1,
      (2,0): 20, 148, 9, 563, 297,
      (3,0): 30, 3, 97, 223, 301,
      (4,0): 40, 98, 34, 416, 295,
      (5,0): 50, -1, -1, -1, -1,
      (6,0): 60, -1, -1, -1, -1,
      (7,0): 70, -1, -1, -1, -1,
      (8,0): 80, -1, -1, -1, -1,
      (9,0): 90, -1, -1, -1, -1,
      (10,0): 100, -1, -1, -1, -1,
      (11,0): 110, -1, -1, -1, -1,
      (12,0): 120, -1, -1, -1, -1
      }
   }
}
}
-

- Each file contains 1+ datasets for each instance, labeled "0", "1", etc.
- Typically, there is only 1 instance in a video.
- The (d x 5) matrix inside each dataset are the annotations for d frames. The 5
  dimensions are: frame_number, xmin, ymin, xmax, ymax.
- The frame stride is 10, i.e. once every 10 frames has an annotation. Frames
  in between two annotations are ignored in the evaluation, altough
  interpolation is also possible.
- In case of -1,-1-,1-,1 for the spatial location, the action is not present in
  the corresponding frame.
- For point annotations, the matrix is (d x 3), with frame_nr, xcenter, ycenter.

---
